<?php

echo crypt('prymestory@2019');

// Username : prymestory@users
// Password : 2019@PrymeStory


//  2019@PrymeStory is : c87192f2acb54117fec2703fd0e46fa4
// echo phpinfo();

?>