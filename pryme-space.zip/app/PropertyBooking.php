<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PropertyBooking extends Model
{
    protected $table = 'tbl_property_bookings';
}
