@component('mail::message')
Thank you for adding a new property with Pryme Space. This is under moderation by Admin.
We request you to please bare with us and allow us some time to verify all of your submitted details. If required, our team can contact you for the verification.

We will try to verify soon, if everything is fine then you we will publish it on the Pryme Space website for it's buyers.

Your patience are appreciated!
@endcomponent
