
@include('front/includes.header')


    @yield('content')


@include('front/includes.footer')

	@yield('script')
    