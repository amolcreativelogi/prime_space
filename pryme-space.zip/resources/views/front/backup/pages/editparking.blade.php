@extends('front/layouts.default')
@section('content')

<div class="site-content">
    Hello this is edit parking
    
</div>
@stop
