 <div class="col-lg-2 col-md-3 col-sm-12 dl-sidebar">
        <ul class="dash-menu">
          <li><a href="<?php echo URL::to('user/customer'); ?>"><img src="{{ URL::asset('public') }}/assets/front-design/images/dashborad.svg" alt=""> Dashboard</a></li>
          <li><a href="<?php echo URL::to('/customer/bookingHistory'); ?>"><img src="{{ URL::asset('public') }}/assets/front-design/images/booking.svg" alt="">Booking history</a></li>
          <li><a href="<?php echo URL::to('customer/orderHistory'); ?>"><img src="{{ URL::asset('public') }}/assets/front-design/images/order-history.png" alt="">order history</a></li>
        </ul>
      </div>



 