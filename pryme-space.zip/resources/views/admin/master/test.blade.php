@extends('admin/layouts.default')
@section('content')
<div id="content">

    <div class="page-header">
    <div class="container-fluid">
     <div class="pull-right"><a href="#" data-toggle="tooltip" title="" class="btn btn-primary" data-original-title="Add New"><i class="fa fa-plus"></i></a>
      </div>
      <h1>Master</h1>
    </div>
  </div>

  <div class="container-fluid"> 
        <div class="panel panel-default">


    <div class="panel-body">       
   <div class="table-responsive">
          <table id="example" class="table table-striped">
            <thead>
              <tr>
              <td>Name</td>
              <td>Last Name</td>
              <td>Address</td>
              <td>Contact Number</td>
              </tr>
            </thead>


            <tbody>
              <tr>
              <td>Amol</td>
              <td>K</td>
              <td>Nagpur</td>
              <td>9970426205</td>
              </tr>

              <tr>
              <td>Amol</td>
              <td>K</td>
              <td>Nagpur</td>
              <td>9970426205</td>
              </tr>

              <tr>
              <td>Amol</td>
              <td>K</td>
              <td>Nagpur</td>
              <td>9970426205</td>
              </tr>

              <tr>
              <td>Amol</td>
              <td>K</td>
              <td>Nagpur</td>
              <td>9970426205</td>
              </tr>

              <tr>
              <td>Amol</td>
              <td>K</td>
              <td>Nagpur</td>
              <td>9970426205</td>
              </tr>

              <tr>
              <td>Amol</td>
              <td>K</td>
              <td>Nagpur</td>
              <td>9970426205</td>
              </tr>

              <tr>
              <td>Amol</td>
              <td>K</td>
              <td>Nagpur</td>
              <td>9970426205</td>
              </tr>

              <tr>
              <td>Amol</td>
              <td>K</td>
              <td>Nagpur</td>
              <td>9970426205</td>
              </tr>


              <tr>
              <td>Amol</td>
              <td>K</td>
              <td>Nagpur</td>
              <td>9970426205</td>
              </tr>

              <tr>
              <td>Amol</td>
              <td>K</td>
              <td>Nagpur</td>
              <td>9970426205</td>
              </tr>

              <tr>
              <td>Amol</td>
              <td>K</td>
              <td>Nagpur</td>
              <td>9970426205</td>
              </tr>


              <tr>
              <td>Amol</td>
              <td>K</td>
              <td>Nagpur</td>
              <td>9970426205</td>
              </tr>
               <tr>
              <td>Amol</td>
              <td>K</td>
              <td>Nagpur</td>
              <td>9970426205</td>
              </tr>
               <tr>
              <td>Amol</td>
              <td>K</td>
              <td>Nagpur</td>
              <td>9970426205</td>
              </tr>
            </tbody>
          </table>
   </div>
                  
</div>
</div>

  
<div class="row">      
<div class="col-lg-6 col-md-12 col-sx-12 col-sm-12">
</div>
</div>
</div>
</div>

</div>
</div>

</div>

<script type="text/javascript">
$(document).ready(function() {
getdatatableRecord('#example','');
});
</script> 
@stop

