@extends('admin/layouts.default')
@section('content')
<div id="content">
  <div class="page-header">
    <div class="container-fluid">
      <h1>Dashboard</h1>      
    </div>
  </div>
  <div class="container-fluid"> 
    <div class="row">
    <div class="col-lg-3"><div class="tile">
    <div class="tile-heading">Users </div>
    <div class="tile-body"><i class="fa fa-users"></i></div>
    <div class="tile-footer"><a href="#"><h2>0</h2></a></div>
    </div>
    </div>  

    <div class="col-lg-3"><div class="tile">
    <div class="tile-heading">Host </div>
    <div class="tile-body"><i class="fa fa-users"></i></div>
    <div class="tile-footer"><a href="#"><h2>0</h2></a></div>
    </div>
    </div>  

    <div class="col-lg-3"><div class="tile">
    <div class="tile-heading">Total Parking Registered</div>
    <div class="tile-body"><i class="fa fa-users"></i></div>
    <div class="tile-footer"><a href="#"><h2>0</h2></a></div>
    </div>
    </div>  

    <div class="col-lg-3"><div class="tile">
    <div class="tile-heading">Total Parking Registered </div>
    <div class="tile-body"><i class="fa fa-users"></i></div>
    <div class="tile-footer"><a href="#"><h2>0</h2></a></div>
    </div>
    </div>  
    </div>
  
  <div class="row">      
      <div class="col-lg-6 col-md-12 col-sx-12 col-sm-12"><link type="text/css" href="view/javascript/jquery/jqvmap/jqvmap.css" rel="stylesheet" media="screen">
  </div>
  </div>
</div>
</div>
</div>
</div>
</div>
@stop

