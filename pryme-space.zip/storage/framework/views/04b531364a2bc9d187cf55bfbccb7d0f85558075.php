<?php $__env->startSection('content'); ?>
<div class="site-content">


<section class="dashboard-layout">
    <div class="row">
     <?php echo $__env->make('front/includes.host_side_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-lg-10 col-md-10 col-sm-12 dl-content">
        <h2 class="dash-title">my parkings</h2>
          <table class="table table-striped viewparking">
    <thead>
     
      <tr>
        <th>Name</th>
        <th>Location</th>
        <th>Status</th>
        <th class="action">Action</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($getParkingList as $plist) {  ?>
      <tr>
        <td><?php echo $plist->name; ?></td>
        <td><?php echo $plist->location; ?></td>
        <td><?php echo ($plist->status == 1) ? 'Active' : 'Inactive'; ?></td>
        <td class="action">
          <a href="#" class="editprop"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
          <a href="<?php echo URL::to('/user/parkingdetails/'.$plist->property_id.''); ?>" class="viewprop"><i class="fa fa-eye" aria-hidden="true"></i></a>
          <a href="#" class="deleteprop" 
          onclick="DeleteRecord('<?php echo $plist->property_id; ?>','prk_add_property','property_id');"><i class="fa fa-trash" aria-hidden="true"></i></a>
        </td>
      </tr>
    <?php } ?>
    </tbody>
  </table>
    </div>
    </div>
</section>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front/layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>