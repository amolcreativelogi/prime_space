<table border="0" cellspacing="0" cellpadding="0" style="margin:0 auto;border:0;width:700px;color:#616161; font-family: Arial, Helvetica, sans-serif;">
    <tbody>
        <tr>
            <td style="border-top:solid 10px #a707a7; background:#FFF;padding:28px 0;text-align: center;"><a href="#"><img src="https://www.prymestory.com/images/logo7.png"></a></td>
        </tr>
        <tr>
            <td style="border-top:solid 1px #e9d1e7; padding:43px 37px;border-bottom:solid 10px #a707a7;">
                <table border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td style="text-align: left;color:#2c2c2c; font-size: 25px;font-weight: bold;">Hello Amol,</td>
                    </tr>
                    <tr>
                        <td style="text-align: left;color:#616161; font-size: 14px;padding:27px 0 30px;line-height: 26px;">Thanks for registering! Your registration request is under admin approval, We will soon notify you regarding approval/disapproval.</td>
                    </tr>
                    <tr>
                        <td style="text-align: left;color:#616161; font-size: 14px;line-height: 26px;text-align: center;padding: 17px 0 12px;">Stay connected with us!</td>
                    </tr>
                    <tr>
                        <td style="text-align: left;color:#616161; font-size: 14px;line-height: 26px;text-align: center;">We wish you a great experience!</td>
                    </tr>
                    <tr>
                        <td style="color:#616161; font-size: 14px;padding: 39px 0 11px;">Cheers,</td>
                    </tr>
                    <tr>
                        <td style="color:#616161; font-size: 14px;">Pryme Story Solution Team!</td>
                    </tr>
                   
                </table>
            </td>
        </tr>
            
    </tbody>
</table>