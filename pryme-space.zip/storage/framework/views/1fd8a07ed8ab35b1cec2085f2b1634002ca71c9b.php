<?php $__env->startSection('content'); ?>
<div class="site-content">

<section class="notification-page dl-content">
  <div class="container">
    <h2 class="dash-title">Notification</h2>
    <table class="table table-striped viewparking">
        <thead>
          <tr>
            <th class="srno">Sr. No.</th>
            <th>Notification</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td class="srno">01</td>
            <td class="note-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard ...</td>
            <td><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></td>
          </tr>
          <tr>
            <td class="srno">02</td>
            <td class="note-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard ...</td>
            <td><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></td>
          </tr>
          <tr>
            <td class="srno">03</td>
            <td class="note-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard ...</td>
            <td><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></td>
          </tr>
          <tr>
            <td class="srno">04</td>
            <td class="note-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard ...</td>
            <td><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></td>
          </tr>
          <tr>
            <td class="srno">05</td>
            <td class="note-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard ...</td>
            <td><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></td>
          </tr>
          <tr>
            <td class="srno">06</td>
            <td class="note-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard ...</td>
            <td><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></td>
          </tr>
          <tr>
            <td class="srno">07</td>
            <td class="note-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard ...</td>
            <td><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></td>
          </tr>
          <tr>
            <td class="srno">08</td>
            <td class="note-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard ...</td>
            <td><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></td>
          </tr>
          <tr>
            <td class="srno">09</td>
            <td class="note-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard ...</td>
            <td><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></td>
          </tr>
          <tr>
            <td class="srno">10</td>
            <td class="note-text">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard ...</td>
            <td><a href=""><i class="fa fa-eye" aria-hidden="true"></i></a></td>
          </tr>
        </tbody>
     </table>
  </div>
</section>

</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('front/layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>