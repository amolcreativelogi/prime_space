<?php $__env->startSection('content'); ?>



<div id="content">
  <div class="page-header">
    <div class="container-fluid">
      <div class="pull-right">
     
        <a href="#" data-toggle="tooltip" title="" class="btn btn-default" data-original-title="Cancel"><i class="fa fa-reply"></i></a></div>
      <h1> Car Type</h1>
      
    </div>
  </div>
  <div class="container-fluid">
        <div class="panel panel-default">
      <div class="panel-heading">
        <h3 class="panel-title"><i class="fa fa-pencil"></i> Add Car Type</h3>
      </div>
      <div class="panel-body">
        <form action="#" method="post" enctype="multipart/form-data" id="form-user" class="form-horizontal">
          <div class="form-group required">
            <label class="col-sm-2 control-label" for="input-username"> Car Type</label>
            <div class="col-sm-10">
              <input type="text" name="username" value="" placeholder=" Car Type" id="input-username" class="form-control">
                          </div>
          </div>
          

           <div class="form-group">
          <div class="col-sm-offset-2 col-sm-10">
          <div class="pull-left">

             <button type="button" class="btn btn-danger pull-right"> Reset</button>
              <button type="button" style="margin-right: 10px;" class="btn btn-primary pull-right"> Save & Continue</button>
            <button type="button" style="margin-right: 10px;" class="btn btn-success pull-right"> Save</button>
           
           
              
        
          </div>
          </div>
          </div>

        </form>
      </div>
    </div>
  </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>