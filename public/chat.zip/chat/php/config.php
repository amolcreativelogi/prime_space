<?php

// Image dir
$imageDir = "image";

// Replace with: your database account
$username 	= "root";
$password 	= "";
$host  		= "localhost";
$name    	= "pryme_space_new_online";
